package com.akula.akfilecl

import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.io.File

@Composable
fun shizukuColor(s: PrivStatus): Color = when (s) {
    PrivStatus.Ready -> Color(0xFF2ECC71)           // green  = connected
    PrivStatus.NeedPermission, PrivStatus.Connecting -> Color(0xFFFFB300)  // amber = almost
    PrivStatus.NotRunning -> Color(0xFFE53935)      // red    = not running
    else -> MaterialTheme.colorScheme.onSurfaceVariant
}

/** The small lightning icon in the top bar: green = Shizuku connected. */
@Composable
fun ShizukuStatusButton(onClick: () -> Unit) {
    IconButton(onClick) {
        Icon(Icons.Filled.Bolt, "Shizuku: ${Priv.status.label}", tint = shizukuColor(Priv.status))
    }
}

@Composable
fun ShizukuDialog(onClose: () -> Unit, onOpenFolder: (File) -> Unit) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { Priv.refresh() }
    val st = Priv.status
    val dataDir = File(Environment.getExternalStorageDirectory(), "Android/data")
    val primary: Pair<String, () -> Unit> = when (st) {
        PrivStatus.NotInstalled -> "Get Shizuku" to { openUrl(ctx, "https://shizuku.rikka.app/download/") }
        PrivStatus.NotRunning -> "Open Shizuku" to {
            ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { ctx.startActivity(it) }
            Unit
        }
        PrivStatus.NeedPermission -> "Grant permission" to { Priv.requestPermission() }
        PrivStatus.Connecting -> "Retry" to { Priv.refresh() }
        PrivStatus.Ready -> "Open Android/data" to { onOpenFolder(dataDir); onClose() }
        PrivStatus.Unsupported -> "OK" to { onClose() }
    }
    val help = when (st) {
        PrivStatus.NotInstalled -> "Install the Shizuku app, start it, then come back here."
        PrivStatus.NotRunning ->
            "Shizuku is installed but stopped. Open it and tap Start (Wireless debugging, or Root if your phone is rooted). " +
                "It must be started again after every phone restart."
        PrivStatus.NeedPermission -> "Shizuku is running. Tap Grant permission and allow AkFileCl."
        PrivStatus.Connecting -> "Starting the file service inside Shizuku. This takes a second."
        PrivStatus.Ready ->
            "Running as: ${Priv.identity.ifEmpty { "shell" }}\n\nAkFileCl can now open Android/data and Android/obb. " +
                "If Shizuku was started with root, the service runs as root."
        PrivStatus.Unsupported -> "Please update the Shizuku app."
    }
    AlertDialog(
        onDismissRequest = onClose,
        icon = { Icon(Icons.Filled.Bolt, null, tint = shizukuColor(st)) },
        title = { Text(st.label) },
        text = { Text(help) },
        confirmButton = { TextButton({ primary.second() }) { Text(primary.first) } },
        dismissButton = {
            Row {
                TextButton({ Priv.refresh() }) { Text("Refresh") }
                TextButton(onClose) { Text("Close") }
            }
        }
    )
}

/** Card on the Home screen with shortcuts to the two folders that need Shizuku. */
@Composable
fun RestrictedCard(onData: () -> Unit, onObb: () -> Unit, onStatus: () -> Unit) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Bolt, null, tint = shizukuColor(Priv.status))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Android/data and Android/obb", color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.titleSmall)
                    Text(Priv.status.label, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onStatus) { Text(if (Priv.ready) "Details" else "Set up") }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onData, Modifier.weight(1f)) {
                    Icon(Icons.Filled.Folder, null); Spacer(Modifier.width(6.dp)); Text("data")
                }
                FilledTonalButton(onObb, Modifier.weight(1f)) {
                    Icon(Icons.Filled.Folder, null); Spacer(Modifier.width(6.dp)); Text("obb")
                }
            }
        }
    }
}
