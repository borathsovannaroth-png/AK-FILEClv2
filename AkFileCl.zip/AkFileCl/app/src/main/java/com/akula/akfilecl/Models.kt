package com.akula.akfilecl

import android.content.Context
import android.os.Environment
import android.os.StatFs
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ensureActive
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val DAY = 24L * 60 * 60 * 1000

data class Item(val file: File, val dir: Boolean, val size: Long, val count: Int, val mod: Long)

fun File.toItem() = Item(
    this, isDirectory,
    if (isDirectory) 0L else length(),
    if (isDirectory) (list()?.size ?: 0) else 0,
    lastModified()
)

enum class Cat(val label: String, val icon: ImageVector, val exts: Set<String>) {
    Images("Images", Icons.Filled.Image, setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")),
    Videos("Videos", Icons.Filled.Videocam, setOf("mp4", "mkv", "3gp", "webm", "avi", "mov")),
    Audio("Audio", Icons.Filled.MusicNote, setOf("mp3", "m4a", "wav", "ogg", "flac", "aac", "opus")),
    Docs("Documents", Icons.Filled.Description, setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub", "csv", "yml", "json")),
    Apks("APKs", Icons.Filled.Android, setOf("apk", "apks", "xapk")),
    Archives("Archives", Icons.Filled.Archive, setOf("zip", "7z", "tar", "gz", "tgz", "rar"))
}

fun catOf(f: File): Cat? {
    val e = f.extension.lowercase()
    return Cat.values().firstOrNull { e in it.exts }
}

sealed class Screen {
    object Home : Screen()
    data class Browse(val dir: File) : Screen()
    data class Category(val cat: Cat) : Screen()
    object Recents : Screen()
    object Settings : Screen()
    data class Archive(val file: File, val inner: String = "") : Screen()
}

enum class ViewKind { Text, Image }

private val TEXT_EXTS = setOf(
    "txt", "log", "md", "json", "xml", "csv", "tsv", "yml", "yaml", "ini", "conf", "cfg", "properties",
    "kt", "kts", "java", "py", "js", "ts", "html", "htm", "css", "sh", "gradle", "toml", "srt", "sql",
    "bat", "smali", "c", "h", "cpp", "rs", "go", "php", "env", "gitignore", "pro", "rc", "lrc"
)

fun viewKind(f: File): ViewKind? {
    val e = f.extension.lowercase()
    return when {
        e in TEXT_EXTS -> ViewKind.Text
        e in Cat.Images.exts && e != "heic" -> ViewKind.Image
        else -> null
    }
}

/** Date + time (hh:mm) for file lists. Follows the Settings screen. */
fun fmtDate(ms: Long): String {
    if (ms <= 0L) return ""
    val pat = when {
        !AppSettings.showTime -> "dd/MM/yy"
        AppSettings.h24 -> "dd/MM/yy HH:mm"
        else -> "dd/MM/yy hh:mm a"
    }
    return SimpleDateFormat(pat, Locale.getDefault()).format(Date(ms))
}

/** Full date and time with seconds, for Properties. */
fun fmtFull(ms: Long): String {
    if (ms <= 0L) return "-"
    val pat = if (AppSettings.h24) "dd MMM yyyy, HH:mm:ss" else "dd MMM yyyy, hh:mm:ss a"
    return SimpleDateFormat(pat, Locale.getDefault()).format(Date(ms))
}

enum class SortBy(val label: String) { Name("Name"), Size("Size"), Date("Date") }

data class Vol(val name: String, val root: File, val total: Long, val free: Long, val sd: Boolean)

fun loadVolumes(ctx: Context): List<Vol> {
    val prim = Environment.getExternalStorageDirectory()
    val out = ArrayList<Vol>()
    fun add(name: String, root: File, sd: Boolean) {
        runCatching {
            val s = StatFs(root.path)
            out.add(Vol(name, root, s.totalBytes, s.availableBytes, sd))
        }
    }
    add("Internal Storage", prim, false)
    ctx.getExternalFilesDirs(null).filterNotNull().forEach { d ->
        val r = File(d.path.substringBefore("/Android/data"))
        if (r.path != prim.path && out.none { it.root.path == r.path }) add("SD Card", r, true)
    }
    return out
}

/** Walks storage on a background thread (call from Dispatchers.IO). Cancellable. */
fun CoroutineScope.scan(root: File, maxDepth: Int, limit: Int, accept: (File) -> Boolean): List<File> {
    val res = ArrayList<File>()
    fun walk(d: File, depth: Int) {
        if (res.size >= limit || depth > maxDepth) return
        val kids = d.listFiles() ?: return
        for (k in kids) {
            ensureActive()
            if (k.name.startsWith(".") && !AppSettings.showHidden) continue
            if (k.isDirectory) {
                if (depth == 0 && k.name == "Android") continue
                walk(k, depth + 1)
            } else if (accept(k)) {
                res.add(k)
                if (res.size >= limit) return
            }
        }
    }
    walk(root, 0)
    return res
}
