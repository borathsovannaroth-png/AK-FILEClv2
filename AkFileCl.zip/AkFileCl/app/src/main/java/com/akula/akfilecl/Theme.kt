package com.akula.akfilecl

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

enum class ThemeMode(val label: String) {
    System("System"), Light("Light"), Dark("Dark"), Blue("Deep Blue")
}

private val LightScheme = lightColorScheme(
    primary = Color(0xFF0061A4), onPrimary = Color.White,
    primaryContainer = Color(0xFFD1E4FF), onPrimaryContainer = Color(0xFF001D36),
    secondaryContainer = Color(0xFFD7E3F8), onSecondaryContainer = Color(0xFF101C2B),
    background = Color(0xFFF8F9FA), onBackground = Color(0xFF191C1E),
    surface = Color(0xFFF8F9FA), onSurface = Color(0xFF191C1E),
    surfaceVariant = Color(0xFFDEE3EB), onSurfaceVariant = Color(0xFF42474E),
    surfaceContainer = Color(0xFFEEF1F4), surfaceContainerHigh = Color(0xFFE6EAEE),
    surfaceContainerLow = Color(0xFFF2F4F7), outline = Color(0xFF72777F)
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF9ECAFF), onPrimary = Color(0xFF003258),
    primaryContainer = Color(0xFF00497D), onPrimaryContainer = Color(0xFFD1E4FF),
    secondaryContainer = Color(0xFF2B4A6B), onSecondaryContainer = Color(0xFFD7E3F8),
    background = Color(0xFF121212), onBackground = Color(0xFFE3E3E3),
    surface = Color(0xFF121212), onSurface = Color(0xFFE3E3E3),
    surfaceVariant = Color(0xFF2C2F33), onSurfaceVariant = Color(0xFFC2C7CF),
    surfaceContainer = Color(0xFF1E1E1E), surfaceContainerHigh = Color(0xFF262626),
    surfaceContainerLow = Color(0xFF1A1A1A), outline = Color(0xFF8C9199)
)

private val BlueScheme = darkColorScheme(
    primary = Color(0xFF4C9AFF), onPrimary = Color(0xFF0A1B33),
    primaryContainer = Color(0xFF1B4A8A), onPrimaryContainer = Color(0xFFD6E6FF),
    secondaryContainer = Color(0xFF1B4A8A), onSecondaryContainer = Color(0xFFD6E6FF),
    background = Color(0xFF0A1B33), onBackground = Color(0xFFE6EEF9),
    surface = Color(0xFF0A1B33), onSurface = Color(0xFFE6EEF9),
    surfaceVariant = Color(0xFF143762), onSurfaceVariant = Color(0xFFA9BCD8),
    surfaceContainer = Color(0xFF10294D), surfaceContainerHigh = Color(0xFF143762),
    surfaceContainerLow = Color(0xFF0F2442), outline = Color(0xFF6F88AD)
)

@Composable
fun AkTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val sysDark = isSystemInDarkTheme()
    val dark = when (mode) {
        ThemeMode.Light -> false
        ThemeMode.Dark, ThemeMode.Blue -> true
        ThemeMode.System -> sysDark
    }
    val scheme = when (mode) {
        ThemeMode.Light -> LightScheme
        ThemeMode.Dark -> DarkScheme
        ThemeMode.Blue -> BlueScheme
        ThemeMode.System -> if (sysDark) DarkScheme else LightScheme
    }
    val view = LocalView.current
    SideEffect {
        val w = (view.context as Activity).window
        w.statusBarColor = scheme.surfaceContainer.toArgb()
        w.navigationBarColor = scheme.background.toArgb()
        val c = WindowCompat.getInsetsController(w, view)
        c.isAppearanceLightStatusBars = !dark
        c.isAppearanceLightNavigationBars = !dark
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
