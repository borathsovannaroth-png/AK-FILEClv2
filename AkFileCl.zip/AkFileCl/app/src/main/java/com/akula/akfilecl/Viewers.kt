@file:OptIn(ExperimentalMaterial3Api::class)

package com.akula.akfilecl

import android.text.format.Formatter
import android.webkit.MimeTypeMap
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

// ------------------------------------------------------------------ text viewer

private class TextData(val lines: List<String>, val truncated: Boolean)

private fun readTextFile(f: File, limit: Int = 1_000_000): TextData {
    Fs.openIn(f).use { ins ->
        val buf = ByteArray(limit)
        var n = 0
        while (n < limit) {
            val r = ins.read(buf, n, limit - n)
            if (r < 0) break
            n += r
        }
        val more = n == limit && ins.read() >= 0
        val text = String(buf, 0, n, Charsets.UTF_8)
        return TextData(text.lines(), more)
    }
}

@Composable
fun TextViewerDialog(f: File, onClose: () -> Unit) {
    var size by remember { mutableIntStateOf(14) }
    var wrap by remember { mutableStateOf(true) }
    val hScroll = rememberScrollState()
    val data by produceState<Result<TextData>?>(null, f) {
        value = withContext(Dispatchers.IO) { runCatching { readTextFile(f) } }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainer).padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClose) { Icon(Icons.Filled.Close, "Close") }
                    Text(
                        f.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium
                    )
                    IconButton({ if (size > 9) size -= 2 }) { Icon(Icons.Filled.Remove, "Smaller text") }
                    IconButton({ if (size < 30) size += 2 }) { Icon(Icons.Filled.Add, "Bigger text") }
                    IconButton({ wrap = !wrap }) { Icon(Icons.Filled.WrapText, "Word wrap") }
                }
                val d = data
                when {
                    d == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    d.isFailure -> EmptyState(Icons.Filled.Error, "Cannot open file", d.exceptionOrNull()?.message ?: "Unknown error")
                    else -> {
                        val t = d.getOrThrow()
                        Column(Modifier.fillMaxSize()) {
                            if (t.truncated) Text(
                                "Showing the first 1 MB only.", fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                            SelectionContainer(Modifier.weight(1f)) {
                                val mod = if (wrap) Modifier.fillMaxSize() else Modifier.fillMaxSize().horizontalScroll(hScroll)
                                LazyColumn(mod, contentPadding = PaddingValues(12.dp)) {
                                    items(t.lines.size) { i ->
                                        Text(
                                            t.lines[i].ifEmpty { " " }, fontFamily = FontFamily.Monospace, fontSize = size.sp,
                                            softWrap = wrap, color = MaterialTheme.colorScheme.onBackground
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ image viewer

@Composable
fun ImageViewerDialog(files: List<File>, start: Int, loader: ImageLoader, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var idx by remember { mutableIntStateOf(start.coerceIn(0, files.lastIndex)) }
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    val f = files[idx]
    fun go(i: Int) { idx = i; scale = 1f; off = Offset.Zero }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(f).size(2048).build(),
                imageLoader = loader, contentDescription = f.name, contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
                    .pointerInput(f.path) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 6f)
                            off = if (scale <= 1f) Offset.Zero else off + pan
                        }
                    }
                    .graphicsLayer { scaleX = scale; scaleY = scale; translationX = off.x; translationY = off.y }
            )
            Row(
                Modifier.fillMaxWidth().background(Color(0x99000000)).padding(horizontal = 4.dp).align(Alignment.TopStart),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClose) { Icon(Icons.Filled.Close, "Close", tint = Color.White) }
                Text(f.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.White)
                if (files.size > 1) Text("${idx + 1} / ${files.size}", color = Color.White, modifier = Modifier.padding(end = 12.dp))
            }
            if (files.size > 1) {
                Row(
                    Modifier.fillMaxWidth().align(Alignment.BottomCenter).padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    FilledTonalIconButton({ go((idx - 1 + files.size) % files.size) }) { Icon(Icons.Filled.ChevronLeft, "Previous") }
                    FilledTonalIconButton({ go((idx + 1) % files.size) }) { Icon(Icons.Filled.ChevronRight, "Next") }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ properties + checksum

private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

@Composable
fun PropertiesDialog(f: File, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val info by produceState<Triple<Stat, Long, Int>?>(null, f) {
        value = withContext(Dispatchers.IO) {
            val st = Fs.stat(f)
            Triple(st, if (st.dir) Fs.sizeOf(f) else st.size, if (st.dir) (Fs.list(f)?.size ?: 0) else 0)
        }
    }
    var sums by remember(f.path) { mutableStateOf<Map<String, String>?>(null) }
    var busy by remember(f.path) { mutableStateOf(false) }
    var err by remember(f.path) { mutableStateOf<String?>(null) }
    var cmp by remember(f.path) { mutableStateOf("") }

    LaunchedEffect(busy) {
        if (!busy) return@LaunchedEffect
        val r = withContext(Dispatchers.IO) {
            runCatching {
                val md5 = MessageDigest.getInstance("MD5")
                val sha1 = MessageDigest.getInstance("SHA-1")
                val sha256 = MessageDigest.getInstance("SHA-256")
                Fs.openIn(f).use { ins ->
                    val b = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(b)
                        if (n < 0) break
                        md5.update(b, 0, n); sha1.update(b, 0, n); sha256.update(b, 0, n)
                        ensureActive()
                    }
                }
                linkedMapOf("MD5" to hex(md5.digest()), "SHA-1" to hex(sha1.digest()), "SHA-256" to hex(sha256.digest()))
            }
        }
        r.onSuccess { sums = it }.onFailure { err = it.message }
        busy = false
    }

    val mime = remember(f.path) { MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) }
    AlertDialog(
        onDismissRequest = onClose, title = { Text("Properties") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                val i = info
                @Composable
                fun row(k: String, v: String) {
                    Text(k, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    SelectionContainer { Text(v, color = MaterialTheme.colorScheme.onSurface) }
                    Spacer(Modifier.height(8.dp))
                }
                row("Name", f.name)
                row("Path", f.path)
                if (i == null) {
                    row("Size", "Calculating...")
                } else {
                    val (st, size, count) = i
                    row("Type", if (st.dir) "Folder" else (mime ?: f.extension.ifEmpty { "File" }))
                    row("Size", Formatter.formatFileSize(ctx, size) + "  (" + "%,d".format(size) + " bytes)")
                    if (st.dir) row("Contains", "$count item(s) at the top level")
                    row("Modified", fmtFull(st.mod))
                    if (!Fs.restricted(f)) {
                        row("Access", listOfNotNull(if (f.canRead()) "read" else null, if (f.canWrite()) "write" else null).joinToString(" + ").ifEmpty { "none" })
                        row("Hidden", if (f.name.startsWith(".")) "Yes" else "No")
                    }
                    if (!st.dir) {
                        HorizontalDivider()
                        Spacer(Modifier.height(8.dp))
                        Text("Checksum", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
                        Spacer(Modifier.height(4.dp))
                        val s = sums
                        when {
                            busy -> Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(12.dp))
                                Text("Calculating...", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            s == null -> {
                                err?.let { Text("Error: $it", color = MaterialTheme.colorScheme.error) }
                                OutlinedButton({ err = null; busy = true }) { Text("Calculate MD5 / SHA-1 / SHA-256") }
                            }
                            else -> {
                                s.forEach { (k, v) ->
                                    Text(k, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                    Text(
                                        v, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    TextButton({ clip.setText(AnnotatedString(v)) }) { Text("Copy") }
                                }
                                OutlinedTextField(
                                    cmp, { cmp = it.trim() }, singleLine = true,
                                    label = { Text("Paste a hash to compare") }, modifier = Modifier.fillMaxWidth()
                                )
                                if (cmp.isNotEmpty()) {
                                    val ok = s.values.any { it.equals(cmp, ignoreCase = true) }
                                    Text(
                                        if (ok) "Match - the file is identical" else "No match",
                                        color = if (ok) Color(0xFF2E9E5B) else MaterialTheme.colorScheme.error,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClose) { Text("OK") } }
    )
}

// ------------------------------------------------------------------ password dialog

@Composable
fun PasswordDlg(title: String, msg: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column {
                if (msg.isNotEmpty()) {
                    Text(msg, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                }
                OutlinedTextField(
                    t, { t = it }, singleLine = true, label = { Text("Password") },
                    visualTransformation = if (show) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton({ show = !show }) {
                            Icon(if (show) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, "Show password")
                        }
                    }
                )
            }
        },
        confirmButton = { TextButton({ if (t.isNotEmpty()) onOk(t) }) { Text("OK") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}
