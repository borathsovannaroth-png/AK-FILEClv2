package com.akula.akfilecl

import android.content.Intent
import android.net.Uri
import android.text.format.Formatter
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.io.File
import java.text.DateFormat
import java.util.Date
import kotlin.math.abs
import kotlin.math.roundToInt

fun iconFor(item: Item): ImageVector {
    if (item.dir) return Icons.Filled.Folder
    return catOf(item.file)?.icon ?: Icons.Filled.InsertDriveFile
}

/** Thumbnail: images/videos are downscaled to 256px and memory-cached by Coil; others show an icon. */
@Composable
fun FileThumb(item: Item, loader: ImageLoader, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val cat = remember(item.file.path) { if (item.dir) null else catOf(item.file) }
    Box(
        modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            iconFor(item), null,
            tint = if (item.dir) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxSize(0.55f)
        )
        if (cat == Cat.Images || cat == Cat.Videos) {
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(item.file)
                    .memoryCacheKey("${item.file.path}:${item.mod}").size(256).crossfade(true).build(),
                imageLoader = loader, contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileRow(
    item: Item, loader: ImageLoader, selecting: Boolean, selected: Boolean,
    onClick: () -> Unit, onLong: () -> Unit
) {
    val ctx = LocalContext.current
    val sub = if (item.dir) (if (item.count >= 0) "${item.count} items  •  " else "") + fmtDate(item.mod)
    else "${Formatter.formatFileSize(ctx, item.size)}  •  ${fmtDate(item.mod)}"
    Row(
        Modifier.fillMaxWidth().heightIn(min = 64.dp)
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selecting) {
            Checkbox(checked = selected, onCheckedChange = null)
            Spacer(Modifier.width(12.dp))
        }
        FileThumb(item, loader, Modifier.size(48.dp))
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(item.file.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.bodyLarge)
            Text(sub, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileCell(
    item: Item, loader: ImageLoader, selecting: Boolean, selected: Boolean,
    onClick: () -> Unit, onLong: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLong),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceContainer
        )
    ) {
        Box {
            FileThumb(item, loader, Modifier.fillMaxWidth().aspectRatio(1f))
            if (selecting) Checkbox(checked = selected, onCheckedChange = null,
                modifier = Modifier.align(Alignment.TopStart).padding(4.dp))
        }
        Text(item.file.name, maxLines = 2, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(8.dp).heightIn(min = 32.dp))
    }
}

@Composable
fun EmptyState(
    icon: ImageVector, title: String, msg: String, modifier: Modifier = Modifier,
    action: (@Composable () -> Unit)? = null
) {
    Column(
        modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f))
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
        Text(msg, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (action != null) { Spacer(Modifier.height(16.dp)); action() }
    }
}

@Composable
fun FileList(
    list: List<Item>?, grid: Boolean, loader: ImageLoader, selecting: Boolean, sel: Set<String>,
    emptyIcon: ImageVector, emptyTitle: String, emptyMsg: String, modifier: Modifier,
    onTap: (Item) -> Unit, onLong: (Item) -> Unit
) {
    Box(modifier) {
        when {
            list == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
            list.isEmpty() -> EmptyState(emptyIcon, emptyTitle, emptyMsg)
            grid -> LazyVerticalGrid(
                GridCells.Fixed(2), Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(list, key = { it.file.path }) { f ->
                    FileCell(f, loader, selecting, f.file.path in sel, { onTap(f) }, { onLong(f) })
                }
            }
            else -> LazyColumn(Modifier.fillMaxSize()) {
                items(list, key = { it.file.path }) { f ->
                    FileRow(f, loader, selecting, f.file.path in sel, { onTap(f) }, { onLong(f) })
                }
            }
        }
    }
}

@Composable
fun BreadcrumbBar(vol: Vol?, dir: File, onGo: (File) -> Unit) {
    val scroll = rememberScrollState()
    val segs = remember(dir, vol) {
        val list = ArrayList<Pair<String, File>>()
        val root = vol?.root ?: dir
        list.add((vol?.name ?: dir.name) to root)
        var cur = root
        runCatching { dir.relativeTo(root).path }.getOrDefault("").split("/").filter { it.isNotEmpty() }.forEach {
            cur = File(cur, it); list.add(it to cur)
        }
        list
    }
    LaunchedEffect(dir) { scroll.animateScrollTo(scroll.maxValue) }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(scroll).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        segs.forEachIndexed { i, seg ->
            if (i > 0) Icon(Icons.Filled.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            val last = i == segs.lastIndex
            Box(
                Modifier.heightIn(min = 48.dp).clip(RoundedCornerShape(8.dp))
                    .clickable { onGo(seg.second) }.padding(horizontal = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(seg.first, maxLines = 1,
                    color = if (last) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.primary,
                    fontWeight = if (last) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}

@Composable
fun StorageCard(v: Vol, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val used = v.total - v.free
    val frac = if (v.total > 0) used.toFloat() / v.total else 0f
    Card(
        modifier = modifier.clip(RoundedCornerShape(12.dp)).clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (v.sd) Icons.Filled.SdCard else Icons.Filled.PhoneAndroid, null,
                    tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(v.name, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                    Text("${Formatter.formatFileSize(ctx, used)} used of ${Formatter.formatFileSize(ctx, v.total)}",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("${(frac * 100).toInt()}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { frac },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
            Spacer(Modifier.height(6.dp))
            Text("${Formatter.formatFileSize(ctx, v.free)} free", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun CategoryCard(label: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceContainer)
            .clickable { onClick() }.heightIn(min = 88.dp).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, maxLines = 1,
            color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun SheetTitle(t: String) {
    Text(t, color = MaterialTheme.colorScheme.onSurface, fontSize = 18.sp, fontWeight = FontWeight.Medium,
        maxLines = 1, overflow = TextOverflow.Ellipsis,
        modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
    HorizontalDivider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
}

@Composable
fun MenuItem(icon: ImageVector, text: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 56.dp).clickable { onClick() }.padding(horizontal = 24.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(20.dp))
        Text(text, color = MaterialTheme.colorScheme.onSurface, fontSize = 17.sp)
    }
}

@Composable
fun TextDlg(title: String, init: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(init) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = { OutlinedTextField(t, { t = it }, singleLine = true) },
        confirmButton = { TextButton({ onOk(t.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}

@Composable
fun CompressDlg(files: List<File>, onDismiss: () -> Unit, onOk: (String, String, String?) -> Unit) {
    var name by remember {
        mutableStateOf(
            if (files.size > 1) "Archive" else if (files[0].isDirectory) files[0].name else files[0].nameWithoutExtension
        )
    }
    var fmt by remember { mutableStateOf("zip") }
    var pw by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Compress ${files.size} item(s)") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Archive name") })
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("zip", "7z", "tar").forEach {
                        FilterChip(selected = fmt == it, onClick = { fmt = it }, label = { Text(".$it") })
                    }
                }
                if (fmt == "zip") {
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        pw, { pw = it }, singleLine = true, label = { Text("Password (optional)") },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                    )
                }
            }
        },
        confirmButton = {
            TextButton({ if (name.isNotBlank()) onOk(name.trim(), fmt, if (fmt == "zip" && pw.isNotEmpty()) pw else null) }) { Text("Compress") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}

fun openUrl(ctx: android.content.Context, url: String) {
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

@Composable
fun CreditPopup(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var off by remember { mutableStateOf(Offset.Zero) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxWidth().padding(20.dp)
                .offset { IntOffset(off.x.roundToInt(), off.y.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragEnd = { if (abs(off.x) > 250f || abs(off.y) > 250f) onClose() else off = Offset.Zero },
                        onDragCancel = { off = Offset.Zero }
                    ) { change, drag -> change.consume(); off += drag }
                }
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
                shape = RoundedCornerShape(28.dp)
            ) {
                Box(Modifier.fillMaxWidth()) {
                    IconButton(onClose, Modifier.align(Alignment.TopEnd)) {
                        Icon(Icons.Filled.Close, "Close", tint = MaterialTheme.colorScheme.onSurface)
                    }
                    Column(
                        Modifier.padding(horizontal = 24.dp).padding(top = 40.dp, bottom = 24.dp)
                            .verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(painterResource(R.drawable.logo), "AkFileCl logo",
                            Modifier.size(84.dp).clip(RoundedCornerShape(20.dp)))
                        Spacer(Modifier.height(16.dp))
                        Text("Appreciate you for use our app", fontSize = 18.sp, fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface)
                        Text("AK-fileCl", fontSize = 30.sp, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(16.dp))
                        Text(
                            "Also we are Akula team we try to make you experience the best version of your phone " +
                                "and also to try more of my app please follow to @zion.orja in tiktok and also " +
                                "please join our telegram for more free app",
                            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button({ openUrl(ctx, "https://www.tiktok.com/@zion.orja") }) { Text("TikTok") }
                            FilledTonalButton({ openUrl(ctx, "https://t.me/+_hWvCNsy13s5NWQ1") }) { Text("Telegram") }
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("Thank my mann", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        Spacer(Modifier.height(8.dp))
                        Text("But btw we can make this thank to our goat Claude thebest ai man 🥹🤧❤️",
                            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface)
                        Spacer(Modifier.height(16.dp))
                        Text("Tap ✕ or swipe away to close", fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
