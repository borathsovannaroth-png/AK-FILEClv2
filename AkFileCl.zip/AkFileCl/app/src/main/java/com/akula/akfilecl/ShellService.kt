package com.akula.akfilecl

import android.content.Context
import android.os.ParcelFileDescriptor
import android.os.Process
import java.io.File

/**
 * Runs inside the Shizuku process (ADB "shell" user, or root if Shizuku was started with root).
 * That user is allowed to read Android/data and Android/obb, which normal apps cannot.
 */
class ShellService : IShellService.Stub {
    constructor() : super()
    constructor(@Suppress("UNUSED_PARAMETER") context: Context) : super()

    override fun destroy() {
        System.exit(0)
    }

    override fun list(path: String): Array<String> {
        return try {
            val kids = File(path).listFiles() ?: return arrayOf("ERR")
            Array(kids.size) { i ->
                val k = kids[i]
                val d = if (k.isDirectory) "1" else "0"
                d + "|" + k.length() + "|" + k.lastModified() + "|" + k.name
            }
        } catch (e: Throwable) {
            arrayOf("ERR")
        }
    }

    /** [type (0 = missing, 1 = file, 2 = folder), size, modified] */
    override fun stat(path: String): LongArray {
        return try {
            val f = File(path)
            if (!f.exists()) longArrayOf(0L, 0L, 0L)
            else longArrayOf(if (f.isDirectory) 2L else 1L, if (f.isDirectory) 0L else f.length(), f.lastModified())
        } catch (e: Throwable) {
            longArrayOf(0L, 0L, 0L)
        }
    }

    override fun delete(path: String): Boolean = try {
        File(path).deleteRecursively()
    } catch (e: Throwable) {
        false
    }

    override fun rename(from: String, to: String): Boolean = try {
        File(from).renameTo(File(to))
    } catch (e: Throwable) {
        false
    }

    override fun mkdirs(path: String): Boolean = try {
        val f = File(path)
        f.isDirectory || f.mkdirs()
    } catch (e: Throwable) {
        false
    }

    override fun openRead(path: String): ParcelFileDescriptor? = try {
        ParcelFileDescriptor.open(File(path), ParcelFileDescriptor.MODE_READ_ONLY)
    } catch (e: Throwable) {
        null
    }

    override fun openWrite(path: String): ParcelFileDescriptor? = try {
        val f = File(path)
        f.parentFile?.mkdirs()
        ParcelFileDescriptor.open(
            f,
            ParcelFileDescriptor.MODE_WRITE_ONLY or ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE
        )
    } catch (e: Throwable) {
        null
    }

    override fun uid(): Int = Process.myUid()
}
