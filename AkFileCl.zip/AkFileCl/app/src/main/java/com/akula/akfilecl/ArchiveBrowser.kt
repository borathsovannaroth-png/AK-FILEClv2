@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.akula.akfilecl

import android.text.format.Formatter
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** What the archive browser can ask the app to do. */
class ArcActions(
    val extract: (Set<String>?) -> Unit,   // null = everything; opens the "Extract to" dialog
    val open: (String) -> Unit,            // entry path -> extract to cache and open
    val test: () -> Unit,
    val password: () -> Unit,
    val remove: (Set<String>) -> Unit,
    val addCopied: () -> Unit,
    val enter: (String) -> Unit            // go into an inner folder
)

private sealed class ArcState {
    object Loading : ArcState()
    class Ok(val list: List<ArcEntry>) : ArcState()
    class NeedPw(val msg: String) : ArcState()
    class Fail(val msg: String) : ArcState()
}

@Composable
fun ArchiveBrowser(
    file: File, inner: String, pw: String?, tick: Int, canAdd: Boolean,
    actions: ArcActions, modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    var state by remember(file.path, pw, tick) { mutableStateOf<ArcState>(ArcState.Loading) }
    LaunchedEffect(file.path, pw, tick) {
        state = ArcState.Loading
        state = withContext(Dispatchers.IO) {
            try {
                ArcState.Ok(Archiver.entries(file, pw))
            } catch (e: PasswordException) {
                ArcState.NeedPw(e.message ?: "Password required")
            } catch (e: Throwable) {
                ArcState.Fail(e.message ?: e.toString())
            }
        }
    }

    var sel by remember(file.path, inner) { mutableStateOf(setOf<String>()) }
    var sheet by remember { mutableStateOf<ArcEntry?>(null) }
    val editable = Archiver.canEdit(file)

    Column(modifier.fillMaxSize()) {
        // path line
        Text(
            file.name + if (inner.isEmpty()) "" else " / " + inner.replace("/", " / "),
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        // tool row
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            if (sel.isEmpty()) {
                FilledTonalButton({ actions.extract(null) }) { Icon(Icons.Filled.Unarchive, null); Spacer(Modifier.width(6.dp)); Text("Extract all") }
                FilledTonalButton({ actions.test() }) { Icon(Icons.Filled.CheckBox, null); Spacer(Modifier.width(6.dp)); Text("Test") }
                FilledTonalButton({ actions.password() }) { Icon(Icons.Filled.Lock, null); Spacer(Modifier.width(6.dp)); Text("Password") }
                if (editable && canAdd) FilledTonalButton({ actions.addCopied() }) {
                    Icon(Icons.Filled.ContentPaste, null); Spacer(Modifier.width(6.dp)); Text("Add copied files")
                }
            } else {
                Text("${sel.size} selected", color = MaterialTheme.colorScheme.onSurface)
                Button({ actions.extract(sel); sel = emptySet() }) { Icon(Icons.Filled.Unarchive, null); Spacer(Modifier.width(6.dp)); Text("Extract") }
                if (editable) FilledTonalButton({ actions.remove(sel); sel = emptySet() }) {
                    Icon(Icons.Filled.Delete, null); Spacer(Modifier.width(6.dp)); Text("Delete")
                }
                TextButton({ sel = emptySet() }) { Text("Cancel") }
            }
        }
        Spacer(Modifier.height(4.dp))

        when (val st = state) {
            ArcState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp))
                    Text("Reading archive...", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            is ArcState.NeedPw -> EmptyState(Icons.Filled.Lock, "Password needed", st.msg) {
                Button(actions.password) { Text("Enter password") }
            }
            is ArcState.Fail -> EmptyState(Icons.Filled.Error, "Cannot read this archive", st.msg)
            is ArcState.Ok -> {
                val kids = remember(st.list, inner) {
                    val prefix = if (inner.isEmpty()) "" else "$inner/"
                    val m = LinkedHashMap<String, ArcEntry>()
                    for (e in st.list) {
                        if (!e.path.startsWith(prefix) || e.path == inner) continue
                        val rest = e.path.substring(prefix.length)
                        val slash = rest.indexOf('/')
                        if (slash < 0) {
                            m[e.path] = e
                        } else {
                            val d = prefix + rest.substring(0, slash)
                            if (!m.containsKey(d)) m[d] = ArcEntry(d, true, 0L, 0L)
                        }
                    }
                    m.values.sortedWith(compareBy<ArcEntry>({ !it.dir }, { it.path.lowercase() }))
                }
                if (kids.isEmpty()) {
                    EmptyState(Icons.Filled.FolderOpen, "This folder is empty", "Nothing inside here.")
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(kids, key = { it.path }) { e ->
                            val selected = e.path in sel
                            val name = e.path.substringAfterLast('/')
                            val sub = buildString {
                                if (!e.dir) append(Formatter.formatFileSize(ctx, e.size))
                                if (e.mod > 0) { if (isNotEmpty()) append("  •  "); append(fmtDate(e.mod)) }
                                if (e.enc) { if (isNotEmpty()) append("  •  "); append("encrypted") }
                            }
                            Row(
                                Modifier.fillMaxWidth().heightIn(min = 60.dp)
                                    .background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                    .combinedClickable(
                                        onClick = {
                                            if (sel.isNotEmpty()) sel = if (selected) sel - e.path else sel + e.path
                                            else if (e.dir) actions.enter(e.path) else sheet = e
                                        },
                                        onLongClick = { sel = if (selected) sel - e.path else sel + e.path }
                                    )
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (sel.isNotEmpty()) {
                                    Checkbox(checked = selected, onCheckedChange = null)
                                    Spacer(Modifier.width(12.dp))
                                }
                                Icon(
                                    if (e.dir) Icons.Filled.Folder else (catOf(File(name))?.icon ?: Icons.Filled.InsertDriveFile),
                                    null,
                                    tint = if (e.dir) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(Modifier.width(16.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurface)
                                    if (sub.isNotEmpty()) Text(
                                        sub, maxLines = 1, style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    sheet?.let { e ->
        ModalBottomSheet(onDismissRequest = { sheet = null }, containerColor = MaterialTheme.colorScheme.surfaceContainer) {
            Column(Modifier.navigationBarsPadding()) {
                SheetTitle(e.path.substringAfterLast('/'))
                MenuItem(Icons.Filled.Visibility, "Open") { sheet = null; actions.open(e.path) }
                MenuItem(Icons.Filled.Unarchive, "Extract...") { sheet = null; actions.extract(setOf(e.path)) }
                if (editable) MenuItem(Icons.Filled.Delete, "Delete from archive") { sheet = null; actions.remove(setOf(e.path)) }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}
