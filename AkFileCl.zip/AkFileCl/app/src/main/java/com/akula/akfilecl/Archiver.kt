package com.akula.akfilecl

import com.github.junrar.Junrar
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.exception.ZipException
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.EncryptionMethod
import org.apache.commons.compress.PasswordRequiredException
import org.apache.commons.compress.archivers.ArchiveInputStream
import org.apache.commons.compress.archivers.ArchiveStreamFactory
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Thrown when an archive needs a password (or the given one is wrong). The UI then asks for it. */
class PasswordException(msg: String) : Exception(msg)

/** One item inside an archive. [path] uses "/" and has no trailing slash. */
data class ArcEntry(val path: String, val dir: Boolean, val size: Long, val mod: Long, val enc: Boolean = false)

enum class Kind { Zip, SevenZ, Tar, TarGz, Rar }

object Archiver {
    /** App cache folder, set once in MainActivity. */
    lateinit var cache: File

    val exts = listOf(".zip", ".7z", ".tar", ".tar.gz", ".tgz", ".rar", ".jar", ".apk", ".apks", ".xapk")

    fun kind(f: File): Kind? {
        val n = f.name.lowercase()
        return when {
            n.endsWith(".tar.gz") || n.endsWith(".tgz") -> Kind.TarGz
            n.endsWith(".tar") -> Kind.Tar
            n.endsWith(".7z") -> Kind.SevenZ
            n.endsWith(".rar") -> Kind.Rar
            n.endsWith(".zip") || n.endsWith(".jar") || n.endsWith(".apk") ||
                n.endsWith(".apks") || n.endsWith(".xapk") -> Kind.Zip
            else -> null
        }
    }

    fun isArchive(f: File) = f.isFile && kind(f) != null

    /** true if this archive type can be changed (delete / add files). */
    fun canEdit(f: File) = kind(f) == Kind.Zip

    fun baseName(f: File): String {
        val n = f.name
        val l = n.lowercase()
        for (e in listOf(".tar.gz", ".tgz", ".tar", ".7z", ".rar", ".zip", ".jar", ".apk", ".apks", ".xapk")) {
            if (l.endsWith(e)) return n.substring(0, n.length - e.length)
        }
        return f.nameWithoutExtension
    }

    fun unique(f: File): File {
        if (!f.exists()) return f
        val base = f.name.substringBefore('.')
        val ext = f.name.removePrefix(base)
        var i = 1
        while (true) {
            val c = File(f.parentFile, "$base ($i)$ext")
            if (!c.exists()) return c
            i++
        }
    }

    fun wanted(name: String, only: Collection<String>?): Boolean =
        only == null || only.any { name == it || name.startsWith(it.trimEnd('/') + "/") }

    // ---------------------------------------------------------------- compress

    fun compress(sources: List<File>, out: File, fmt: String, pw: String? = null) {
        when (fmt) {
            "zip" -> if (pw.isNullOrEmpty()) {
                ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { z ->
                    sources.forEach { addZip(z, it, it.parentFile!!) }
                }
            } else {
                val zf = ZipFile(out, pw.toCharArray())
                val p = ZipParameters()
                p.setEncryptFiles(true)
                p.setEncryptionMethod(EncryptionMethod.AES)
                p.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256)
                for (s in sources) {
                    if (s.isDirectory) zf.addFolder(s, p) else zf.addFile(s, p)
                }
            }
            "7z" -> SevenZOutputFile(out).use { s ->
                sources.forEach { add7z(s, it, it.parentFile!!) }
            }
            "tar" -> TarArchiveOutputStream(BufferedOutputStream(FileOutputStream(out))).use { t ->
                t.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
                sources.forEach { addTar(t, it, it.parentFile!!) }
            }
        }
    }

    private fun rel(f: File, base: File) = f.relativeTo(base).path.replace('\\', '/')

    private fun addZip(z: ZipOutputStream, f: File, base: File) {
        if (f.isDirectory) {
            z.putNextEntry(ZipEntry(rel(f, base) + "/")); z.closeEntry()
            f.listFiles()?.forEach { addZip(z, it, base) }
        } else {
            z.putNextEntry(ZipEntry(rel(f, base)))
            FileInputStream(f).use { it.copyTo(z) }
            z.closeEntry()
        }
    }

    private fun add7z(s: SevenZOutputFile, f: File, base: File) {
        s.putArchiveEntry(s.createArchiveEntry(f, rel(f, base)))
        if (f.isFile) {
            FileInputStream(f).use { i ->
                val b = ByteArray(8192); var r: Int
                while (i.read(b).also { r = it } >= 0) s.write(b, 0, r)
            }
        }
        s.closeArchiveEntry()
        if (f.isDirectory) f.listFiles()?.forEach { add7z(s, it, base) }
    }

    private fun addTar(t: TarArchiveOutputStream, f: File, base: File) {
        t.putArchiveEntry(TarArchiveEntry(f, rel(f, base)))
        if (f.isFile) FileInputStream(f).use { it.copyTo(t) }
        t.closeArchiveEntry()
        if (f.isDirectory) f.listFiles()?.forEach { addTar(t, it, base) }
    }

    // ---------------------------------------------------------------- listing

    fun entries(a: File, pw: String? = null): List<ArcEntry> {
        val raw = when (kind(a)) {
            Kind.Zip -> zipEntries(a)
            Kind.SevenZ -> sevenEntries(a, pw)
            Kind.Tar, Kind.TarGz -> tarEntries(a)
            Kind.Rar -> rarEntries(a, pw)
            null -> throw IOException("Not a supported archive")
        }
        // an entry that has children is a folder
        val parents = HashSet<String>()
        for (e in raw) {
            var p = e.path
            while (p.contains('/')) {
                p = p.substringBeforeLast('/')
                parents.add(p)
            }
        }
        return raw.map { if (!it.dir && it.path in parents) it.copy(dir = true) else it }
    }

    private fun zipFile(a: File, pw: String?): ZipFile =
        if (pw.isNullOrEmpty()) ZipFile(a) else ZipFile(a, pw.toCharArray())

    private fun zipEntries(a: File): List<ArcEntry> =
        zipFile(a, null).fileHeaders.map {
            ArcEntry(it.fileName.replace('\\', '/').trimEnd('/'), it.isDirectory, it.uncompressedSize, it.lastModifiedTimeEpoch, it.isEncrypted)
        }

    private fun sevenOpen(a: File, pw: String?): SevenZFile =
        if (pw.isNullOrEmpty()) SevenZFile(a) else SevenZFile(a, pw.toCharArray())

    private fun sevenEntries(a: File, pw: String?): List<ArcEntry> {
        val out = ArrayList<ArcEntry>()
        try {
            sevenOpen(a, pw).use { s ->
                for (e in s.entries) {
                    out.add(
                        ArcEntry(
                            e.name.replace('\\', '/').trimEnd('/'), e.isDirectory, e.size,
                            if (e.hasLastModifiedDate) e.lastModifiedDate.time else 0L
                        )
                    )
                }
            }
        } catch (e: PasswordRequiredException) {
            throw PasswordException("This 7z archive is password protected")
        }
        return out
    }

    private fun tarEntries(a: File): List<ArcEntry> {
        val out = ArrayList<ArcEntry>()
        openTar(a).use { s ->
            var e = s.nextEntry
            while (e != null) {
                out += ArcEntry(e.name.replace('\\', '/').trimEnd('/'), e.isDirectory, e.size, e.lastModifiedDate?.time ?: 0L)
                e = s.nextEntry
            }
        }
        return out
    }

    /**
     * RAR is unpacked once into a temp folder (cache/rar_x) and that folder is used for browsing,
     * opening and extracting. The temp folders are deleted when the app starts.
     */
    private fun rarWork(a: File, pw: String?): File {
        val dir = File(cache, "rar_x/" + (a.path + a.lastModified() + a.length()).hashCode())
        val done = File(dir, ".akdone")
        if (done.exists()) return dir
        dir.deleteRecursively()
        dir.mkdirs()
        try {
            if (pw.isNullOrEmpty()) Junrar.extract(a, dir) else Junrar.extract(a, dir, pw)
        } catch (e: Exception) {
            dir.deleteRecursively()
            if (e.javaClass.simpleName.contains("V5")) {
                throw IOException("This is a RAR5 archive. AkFileCl can open RAR4 archives only for now.")
            }
            throw PasswordException(
                if (pw.isNullOrEmpty()) "Cannot open this RAR: ${e.message}. If it is password protected, enter the password."
                else "Wrong password, or this RAR cannot be read (${e.message})"
            )
        }
        done.writeText("ok")
        return dir
    }

    private fun rarEntries(a: File, pw: String?): List<ArcEntry> {
        val dir = rarWork(a, pw)
        val list = ArrayList<ArcEntry>()
        dir.walkTopDown().forEach { f ->
            if (f != dir && f.name != ".akdone") {
                list.add(
                    ArcEntry(
                        f.relativeTo(dir).path.replace('\\', '/'), f.isDirectory,
                        if (f.isFile) f.length() else 0L, f.lastModified()
                    )
                )
            }
        }
        return list
    }

    // ---------------------------------------------------------------- extract

    private fun openTar(a: File): ArchiveInputStream {
        var ins: InputStream = BufferedInputStream(FileInputStream(a))
        if (kind(a) == Kind.TarGz) ins = BufferedInputStream(GzipCompressorInputStream(ins))
        return ArchiveStreamFactory().createArchiveInputStream(ins)
    }

    private fun safe(dest: File, name: String): File {
        val f = File(dest, name).canonicalFile
        require(f.path.startsWith(dest.canonicalPath)) { "Unsafe path in archive: $name" }
        return f
    }

    /** Extract everything ([only] == null) or just the chosen entries (folders include their content). */
    fun extract(a: File, dest: File, pw: String? = null, only: Collection<String>? = null) {
        dest.mkdirs()
        when (kind(a)) {
            Kind.Zip -> zipExtract(a, dest, pw, only)
            Kind.SevenZ -> sevenExtract(a, dest, pw, only)
            Kind.Tar, Kind.TarGz -> tarExtract(a, dest, only)
            Kind.Rar -> rarExtract(a, dest, pw, only)
            null -> throw IOException("Not a supported archive")
        }
    }

    private fun zipExtract(a: File, dest: File, pw: String?, only: Collection<String>?) {
        val zf = zipFile(a, pw)
        for (h in zf.fileHeaders) {
            val name = h.fileName.replace('\\', '/').trimEnd('/')
            if (!wanted(name, only)) continue
            if (h.isEncrypted && pw.isNullOrEmpty()) throw PasswordException("This zip is password protected")
            try {
                zf.extractFile(h, dest.path)
            } catch (e: ZipException) {
                if (e.type == ZipException.Type.WRONG_PASSWORD) throw PasswordException("Wrong password")
                throw e
            }
        }
    }

    private fun sevenExtract(a: File, dest: File, pw: String?, only: Collection<String>?) {
        try {
            sevenOpen(a, pw).use { s ->
                var e = s.nextEntry
                while (e != null) {
                    val name = e.name.replace('\\', '/').trimEnd('/')
                    if (wanted(name, only)) {
                        val f = safe(dest, name)
                        if (e.isDirectory) f.mkdirs() else {
                            f.parentFile?.mkdirs()
                            FileOutputStream(f).use { o ->
                                val b = ByteArray(8192); var r: Int
                                while (s.read(b).also { r = it } >= 0) o.write(b, 0, r)
                            }
                        }
                    }
                    e = s.nextEntry
                }
            }
        } catch (e: PasswordRequiredException) {
            throw PasswordException("This 7z archive is password protected")
        } catch (e: IOException) {
            if (!pw.isNullOrEmpty()) throw PasswordException("Wrong password or damaged archive")
            throw e
        }
    }

    private fun tarExtract(a: File, dest: File, only: Collection<String>?) {
        openTar(a).use { s ->
            var e = s.nextEntry
            while (e != null) {
                val name = e.name.replace('\\', '/').trimEnd('/')
                if (wanted(name, only)) {
                    val f = safe(dest, name)
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs()
                        FileOutputStream(f).use { s.copyTo(it) }
                    }
                }
                e = s.nextEntry
            }
        }
    }

    private fun rarExtract(a: File, dest: File, pw: String?, only: Collection<String>?) {
        val dir = rarWork(a, pw)
        dir.walkTopDown().forEach { f ->
            if (f != dir && f.name != ".akdone") {
                val r = f.relativeTo(dir).path.replace('\\', '/')
                if (wanted(r, only)) {
                    val t = safe(dest, r)
                    if (f.isDirectory) t.mkdirs() else {
                        t.parentFile?.mkdirs()
                        f.copyTo(t, true)
                    }
                }
            }
        }
    }

    /** Extracts one file into the cache so it can be viewed / opened. */
    fun extractOne(a: File, entry: String, pw: String?): File {
        val dest = File(cache, "arc_open/${System.nanoTime()}")
        dest.mkdirs()
        extract(a, dest, pw, listOf(entry))
        return File(dest, entry)
    }

    fun test(a: File, pw: String? = null) {
        val tmp = File(cache, "test_${System.nanoTime()}")
        try {
            extract(a, tmp, pw)
        } finally {
            tmp.deleteRecursively()
        }
    }

    // ---------------------------------------------------------------- edit (zip only)

    fun removeEntries(a: File, paths: Collection<String>, pw: String?) {
        if (kind(a) != Kind.Zip) throw IOException("Only .zip files can be edited")
        val zf = zipFile(a, pw)
        val names = zf.fileHeaders.map { it.fileName }.filter { wanted(it.replace('\\', '/').trimEnd('/'), paths) }
        for (n in names.sortedDescending()) {
            if (zf.getFileHeader(n) != null) zf.removeFile(n)
        }
    }

    fun addFiles(a: File, files: List<File>, innerDir: String, pw: String?) {
        if (kind(a) != Kind.Zip) throw IOException("Only .zip files can be edited")
        val zf = zipFile(a, pw)
        val encrypted = !pw.isNullOrEmpty() && zf.isEncrypted
        fun add(f: File, nameInZip: String) {
            if (f.isDirectory) {
                f.listFiles()?.forEach { add(it, nameInZip + "/" + it.name) }
            } else {
                val p = ZipParameters()
                p.setFileNameInZip(nameInZip)
                if (encrypted) {
                    p.setEncryptFiles(true)
                    p.setEncryptionMethod(EncryptionMethod.AES)
                    p.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256)
                }
                zf.addFile(f, p)
            }
        }
        for (f in files) add(f, if (innerDir.isEmpty()) f.name else innerDir + "/" + f.name)
    }
}
